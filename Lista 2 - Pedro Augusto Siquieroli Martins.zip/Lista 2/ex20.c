#include <stdio.h>
#include <stdbool.h>

bool eh_primo(int num) {
    if(num < 2) return false;
    for(int i = 2; i * i <= num; i++) {
        if(num % i == 0) return false;
    }
    return true;
}

void primos_abaixo(int n) {
    printf("Primos abaixo de %d: ", n);
    for(int i = 2; i < n; i++) {
        if(eh_primo(i)) {
            printf("%d ", i);
        }
    }
    printf("\n");
}

int main() {
    int limite;
    printf("Digite N: ");
    scanf("%d", &limite);
    primos_abaixo(limite);
    return 0;
}