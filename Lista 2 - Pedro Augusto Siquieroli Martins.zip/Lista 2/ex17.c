#include <stdio.h>

int soma_entre_numeros(int a, int b) {
    int inicio = a < b ? a : b;
    int fim = a > b ? a : b;
    int soma = 0;
    
    for(int i = inicio + 1; i < fim; i++) {
        soma += i;
    }
    return soma;
}

int main() {
    int n1, n2;
    printf("Número 1: ");
    scanf("%d", &n1);
    printf("Número 2: ");
    scanf("%d", &n2);
    printf("Soma entre eles: %d\n", soma_entre_numeros(n1, n2));
    return 0;
}