#include <stdio.h>
#define PI 3.141592

float volume_cilindro(float altura, float raio) {
    return PI * raio * raio * altura;
}

int main() {
    float h, r;
    printf("Altura do cilindro: ");
    scanf("%f", &h);
    printf("Raio do cilindro: ");
    scanf("%f", &r);
    printf("Volume: %.2f\n", volume_cilindro(h, r));
    return 0;
}