#include <stdio.h>

float calcular_raiz_quadrada(float numero) {
    if (numero == 0) return 0;
    
    float raiz = numero / 2; 
    float precisao = 0.0001;
    
    while (1) {
        float nova_raiz = (raiz + numero / raiz) / 2;
        
        if (nova_raiz >= raiz - precisao && nova_raiz <= raiz + precisao) {
            break;
        }
        raiz = nova_raiz;
    }
    return raiz;
}

float hipotenusa(float a, float b) {
    float soma_quadrados = a*a + b*b;
    return calcular_raiz_quadrada(soma_quadrados);
}


int main() {
    float cateto1, cateto2;
    
    printf("Digite o valor do primeiro cateto: ");
    scanf("%f", &cateto1);
    
    printf("Digite o valor do segundo cateto: ");
    scanf("%f", &cateto2);
    
    if (cateto1 <= 0 || cateto2 <= 0) {
        printf("Erro: Os catetos devem ser valores positivos!\n");
        return 1;
    }
    
    float resultado = hipotenusa(cateto1, cateto2);
    printf("Hipotenusa: %.4f\n", resultado);
    
    return 0;
}