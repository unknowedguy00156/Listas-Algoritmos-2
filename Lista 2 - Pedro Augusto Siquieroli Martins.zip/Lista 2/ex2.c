#include <stdio.h>

void data_por_extenso(int dia, int mes, int ano) {
    const char *meses[] = {
        "janeiro", "fevereiro", "março", "abril", "maio", "junho",
        "julho", "agosto", "setembro", "outubro", "novembro", "dezembro"
    };
    
    if(mes < 1 || mes > 12) {
        printf("Mês inválido!\n");
        return;
    }
    
    printf("%d de %s de %d\n", dia, meses[mes-1], ano);
}

int main() {
    int d, m, a;
    printf("Dia: ");
    scanf("%d", &d);
    printf("Mês: ");
    scanf("%d", &m);
    printf("Ano: ");
    scanf("%d", &a);
    data_por_extenso(d, m, a);
    return 0;
}