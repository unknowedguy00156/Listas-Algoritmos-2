#include <stdio.h>


int Segundos(int horas, int minutos, int segundos);
int main(){
int horas = 0, minutos = 0,segundos = 0;

printf("Digite a quantidade de horas: ");
scanf("%d",&horas);
printf("Digite a quantidade de minutos: ");
scanf("%d",&minutos);
printf("Digite a quantidade de segundos: ");
scanf("%d",&segundos);

printf("%d horas, %d minutos e %d segundos equivalem a %d segundos.", horas, minutos, segundos, Segundos( horas, minutos,  segundos));

return 0;

}

int Segundos(int horas, int minutos, int segundos){
    return (horas * 3600) + (minutos * 60) + segundos;
}