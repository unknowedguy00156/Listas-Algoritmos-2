#include <stdio.h>

int potencia(int x, int z) {
    int resultado = 1;
    for(int i = 0; i < z; i++) {
        resultado *= x;
    }
    return resultado;
}

int main() {
    int base, expoente;
    printf("Base: ");
    scanf("%d", &base);
    printf("Expoente: ");
    scanf("%d", &expoente);
    printf("Resultado: %d\n", potencia(base, expoente));
    return 0;
}