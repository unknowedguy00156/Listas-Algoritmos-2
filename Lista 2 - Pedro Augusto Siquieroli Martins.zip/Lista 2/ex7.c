#include <stdio.h>

float grausFahrenheit(float celsius);

int main(){
 float celsius = 0.0;

 printf("Digite a temperatura em celsius: ");
 scanf("%f",&celsius);
 printf("A temperatura em graus Fahrenheit é %.2f",grausFahrenheit(celsius));



}

float grausFahrenheit(float celsius){
    return celsius*(9.0/5.0)+32.0;
}