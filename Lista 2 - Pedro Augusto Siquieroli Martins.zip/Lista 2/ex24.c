#include <stdio.h>

void triangulo_completo(int n) {
    // Parte crescente
    for(int i = 1; i <= n; i++) {
        // Espaços
        for(int j = 0; j < n - i; j++) {
            printf(" ");
        }
        // Asteriscos
        for(int j = 0; j < 2*i - 1; j++) {
            printf("*");
        }
        printf("\n");
    }
}

int main() {
    int altura;
    printf("Altura do triângulo: ");
    scanf("%d", &altura);
    triangulo_completo(altura);
    return 0;
}