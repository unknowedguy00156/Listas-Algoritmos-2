# include <stdio.h>

int verificarNumero(float x);

int main(){
    float num;
   

    printf("Digite um número: ");
    scanf("%f",&num);
    printf("%d",verificarNumero(num));



}

int verificarNumero(float x){
    if(x>0) return 1;
    else if(x<0) return -1;
    else return 0;
}