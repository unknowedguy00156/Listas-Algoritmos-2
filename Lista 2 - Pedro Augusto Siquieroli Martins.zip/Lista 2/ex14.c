#include <stdio.h>

void consumo_carro(float km, float litros) {
    float consumo = km / litros;
    
    if(consumo < 8) {
        printf("Venda o carro!\n");
    } else if(consumo >= 8 && consumo <= 14) {
        printf("Econômico!\n");
    } else {
        printf("Super econômico!\n");
    }
}

int main() {
    float distancia, combustivel;
    printf("Distância (km): ");
    scanf("%f", &distancia);
    printf("Litros consumidos: ");
    scanf("%f", &combustivel);
    consumo_carro(distancia, combustivel);
    return 0;
}