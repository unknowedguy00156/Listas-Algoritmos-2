#include <stdio.h>


int ehQuadradoPerfeito(int n) {
    if (n < 0) return 0;

    int i = 0;
    while (i * i <= n) {
        if (i * i == n)
            return 1;
        i++;
    }
    return 0;
}

int main() {
    int num;
    printf("Digite um número inteiro: ");
    scanf("%d", &num);

    if (ehQuadradoPerfeito(num)) {
        printf("%d é um quadrado perfeito.\n", num);
    } else {
        printf("%d não é um quadrado perfeito.\n", num);
    }

    return 0;
}
