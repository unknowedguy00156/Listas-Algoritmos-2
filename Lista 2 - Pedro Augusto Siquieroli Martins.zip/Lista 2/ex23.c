#include <stdio.h>

void triangulo_lateral(int n) {
    // Parte crescente
    for(int i = 1; i <= n; i++) {
        for(int j = 0; j < i; j++) {
            printf("*");
        }
        printf("\n");
    }
    
    // Parte decrescente
    for(int i = n-1; i >= 1; i--) {
        for(int j = 0; j < i; j++) {
            printf("*");
        }
        printf("\n");
    }
}

int main() {
    int tamanho;
    printf("Tamanho do triângulo: ");
    scanf("%d", &tamanho);
    triangulo_lateral(tamanho);
    return 0;
}