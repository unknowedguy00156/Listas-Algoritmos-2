#include <stdio.h>

long fatorial(int n) {
    long fat = 1;
    for(int i = 1; i <= n; i++) {
        fat *= i;
    }
    return fat;
}

int main() {
    int num;
    printf("Número: ");
    scanf("%d", &num);
    printf("%d! = %ld\n", num, fatorial(num));
    return 0;
}