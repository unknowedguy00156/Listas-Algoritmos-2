#include <stdio.h>

void triangulo_exclamacoes(int n) {
    for(int i = 1; i <= n; i++) {
        for(int j = 0; j < i; j++) {
            printf("!");
        }
        printf("\n");
    }
}

int main() {
    int altura;
    printf("Altura do triângulo: ");
    scanf("%d", &altura);
    triangulo_exclamacoes(altura);
    return 0;
}