#include <stdio.h>

float maior_numero(float a, float b) {
    return a > b ? a : b;
}

int main() {
    float n1, n2;
    printf("Primeiro número: ");
    scanf("%f", &n1);
    printf("Segundo número: ");
    scanf("%f", &n2);
    printf("Maior: %.2f\n", maior_numero(n1, n2));
    return 0;
}