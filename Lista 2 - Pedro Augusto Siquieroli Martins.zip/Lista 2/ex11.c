#include <stdio.h>

float media_notas(float n1, float n2, float n3, char tipo) {
    if(tipo == 'A') {
        return (n1 + n2 + n3) / 3.0;
    } else if(tipo == 'P') {
        return (n1*5 + n2*3 + n3*2) / 10.0;
    }
    return 0;
}

int main() {
    float nota1, nota2, nota3;
    char tipo_media;
    
    printf("Nota 1: ");
    scanf("%f", &nota1);
    printf("Nota 2: ");
    scanf("%f", &nota2);
    printf("Nota 3: ");
    scanf("%f", &nota3);
    printf("Tipo (A/P): ");
    scanf(" %c", &tipo_media);
    
    printf("Média: %.2f\n", media_notas(nota1, nota2, nota3, tipo_media));
    return 0;
}