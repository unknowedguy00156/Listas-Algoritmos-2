#include <stdio.h>

int dobro(int x);

int main(){
    int n = 0; int resultado = 0;

    printf("Digite um numero inteiro: ");
    scanf("%d",&n);
    resultado = dobro(n);
    printf("O dobro de %d eh %d",n, resultado);

    return 0;

}

int dobro(int x){
 return x*2;
}