#include <stdio.h>
#define PI 3.141592

float volume_esfera(float raio) {
    return (4.0/3.0) * PI * raio * raio * raio;
}

int main() {
    float r;
    printf("Raio da esfera: ");
    scanf("%f", &r);
    printf("Volume: %.2f\n", volume_esfera(r));
    return 0;
}