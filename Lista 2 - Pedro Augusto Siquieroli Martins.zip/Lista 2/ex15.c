#include <stdio.h>

float forma_triangulo(float a, float b, float c) {
    return (a < b + c) && (b < a + c) && (c < a + b);
}

void tipo_triangulo(float a, float b, float c) {
    if(a == b && b == c) {
        printf("Equilátero\n");
    } else if(a == b || a == c || b == c) {
        printf("Isósceles\n");
    } else {
        printf("Escaleno\n");
    }
}

int main() {
    float l1, l2, l3;
    printf("Lado 1: ");
    scanf("%f", &l1);
    printf("Lado 2: ");
    scanf("%f", &l2);
    printf("Lado 3: ");
    scanf("%f", &l3);
    
    if(forma_triangulo(l1, l2, l3)) {
        printf("Forma triângulo: ");
        tipo_triangulo(l1, l2, l3);
    } else {
        printf("Não forma triângulo!\n");
    }
    return 0;
}