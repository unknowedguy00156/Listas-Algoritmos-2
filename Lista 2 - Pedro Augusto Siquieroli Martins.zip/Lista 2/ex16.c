#include <stdio.h>
int n=0;

char desenha_linha(int n);

int main(){
  
printf("Digite um número inteiro: ");
scanf("%d",&n);

printf("%c", desenha_linha(n));  
}

   
char desenha_linha(int n)
{
    for(int i=1;i<=n;i++){
        printf("=");
    }
}