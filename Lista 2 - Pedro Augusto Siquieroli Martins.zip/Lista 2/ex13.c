#include <stdio.h>

float calculadora(float a, float b, char operador) {
    switch(operador) {
        case '+': return a + b;
        case '-': return a - b;
        case '*': return a * b;
        case '/': 
            if(b != 0) return a / b;
            printf("Erro: divisão por zero!\n");
            return 0;
        default:
            printf("Operador inválido!\n");
            return 0;
    }
}

int main() {
    float n1, n2;
    char op;
    
    printf("Número 1: ");
    scanf("%f", &n1);
    printf("Número 2: ");
    scanf("%f", &n2);
    printf("Operador (+, -, *, /): ");
    scanf(" %c", &op);
    
    printf("Resultado: %.2f\n", calculadora(n1, n2, op));
    return 0;
}