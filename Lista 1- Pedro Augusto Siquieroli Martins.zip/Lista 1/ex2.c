# include <stdio.h>

int main(){

char resposta;

printf("vertebrado ou invertebrado?");
scanf("%s",&resposta);
if(resposta=="vertebrado"){
    
}else{
    printf("vertebrado ou invertebrado?");
    scanf("%s",&resposta);
}


}