#include <stdio.h>

int main() {
    int matriz[4][5], menor, linha, coluna;
    
    for (int i = 0; i < 4; i++) {
        for (int j = 0; j < 5; j++) {
            scanf("%d", &matriz[i][j]);
            
            if (i == 0 && j == 0) {
                menor = matriz[i][j];
                linha = i;
                coluna = j;
            } else if (matriz[i][j] < menor) {
                menor = matriz[i][j];
                linha = i;
                coluna = j;
            }
        }
    }
    
    printf("Menor valor: %d\nPosição: [%d][%d]", menor, linha, coluna);
    
    return 0;
}