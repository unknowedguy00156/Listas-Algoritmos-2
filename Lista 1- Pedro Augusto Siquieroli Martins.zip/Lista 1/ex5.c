#include <stdio.h>

int main() {
    int n;
    printf("Digite um número: ");
    scanf("%d", &n);
    
    for (int i = 1; i <= 2*n; i += 2) {
        printf("%d ", i);
        if (i < 2*n - 1);
    }
    
    return 0;
}