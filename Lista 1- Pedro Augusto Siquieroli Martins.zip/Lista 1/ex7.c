#include <stdio.h>
#include <limits.h>

int main() {
    int vetor[10];
    
    for (int i = 0; i < 10; i++) {
        scanf("%d", &vetor[i]);
    }
    
    // Encontrar os 3 menores valores
    int menor1 = INT_MAX, menor2 = INT_MAX, menor3 = INT_MAX;
    
    for (int i = 0; i < 10; i++) {
        if (vetor[i] < menor1) {
            menor3 = menor2;
            menor2 = menor1;
            menor1 = vetor[i];
        } else if (vetor[i] < menor2 && vetor[i] != menor1) {
            menor3 = menor2;
            menor2 = vetor[i];
        } else if (vetor[i] < menor3 && vetor[i] != menor1 && vetor[i] != menor2) {
            menor3 = vetor[i];
        }
    }
    
    printf("Os 3 menores valores são: %d, %d, %d", menor1, menor2, menor3);
    
    return 0;
}