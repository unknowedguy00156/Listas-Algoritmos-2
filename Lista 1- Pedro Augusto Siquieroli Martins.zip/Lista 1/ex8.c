#include <stdio.h>

int main() {
    float valores[5], soma = 0, maior, menor;
    
    printf("<< 5 valores >>\n");
    for (int i = 0; i < 5; i++) {
        printf("Entre com o número %d: ", i+1);
        scanf("%f", &valores[i]);
        soma += valores[i];
        
        if (i == 0) {
            maior = menor = valores[i];
        } else {
            if (valores[i] > maior) maior = valores[i];
            if (valores[i] < menor) menor = valores[i];
        }
    }
    
    printf("\nOs números digitados são: ");
    for (int i = 0; i < 5; i++) {
        printf("%.0f ", valores[i]);
    }
    
    printf("\nO maior valor é: %.0f", maior);
    printf("\nO menor valor é: %.0f", menor);
    printf("\nA média é: %.1f", soma/5);
    
    return 0;
}