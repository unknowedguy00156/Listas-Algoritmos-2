#include <stdio.h>

int main(){
    int i=10;
    while(i>=0){
     printf("%d...",i);
     i--;
    }
}
