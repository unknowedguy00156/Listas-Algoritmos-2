#include <stdio.h>

int main(){
    
   float altura = 0; 
     printf("Digite a altura da pessoa: ");
     scanf("%f",&altura);
     

     if(altura<=1.50){
        printf("muito baixo");
     }
     else if(altura >1.50 && altura<= 1.60){
        printf("baixo");
     }
     else if(altura >1.60 && altura<= 1.80){
        printf("mediano");
     }
     else if(altura>1.80){
        printf("alto");
     }   
    
    return 0;
}
