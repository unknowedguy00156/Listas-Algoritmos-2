#include <stdio.h>

int main() {
    int n, i, j, count = 0, num = 0;
    printf("Digite 3 valores: ");
    scanf("%d %d %d", &n, &i, &j);
    
    while (count < n) {
        if (num % i == 0 || num % j == 0) {
            printf("%d", num);
            count++;
            if (count < n) printf(",");
        }
        num++;
    }
    
    return 0;
}