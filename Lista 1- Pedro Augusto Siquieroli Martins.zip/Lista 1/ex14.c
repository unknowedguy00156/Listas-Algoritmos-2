#include <stdio.h>

typedef struct {
    int DDD;
    char telefone[15];
} Telefone;

int main() {
    Telefone tel[2];
    
    for (int i = 0; i < 2; i++) {
        printf("Digite o DDD: ");
        scanf("%d", &tel[i].DDD);
        printf("Digite o telefone: ");
        scanf("%s", tel[i].telefone);
    }
    
    printf("\nTelefones cadastrados:\n");
    for (int i = 0; i < 2; i++) {
        printf("(%d) %s\n", tel[i].DDD, tel[i].telefone);
    }
    
    return 0;
}