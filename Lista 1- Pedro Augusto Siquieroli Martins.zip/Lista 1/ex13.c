#include <stdio.h>

typedef struct {
    float x;
    float y;
} Ponto;

typedef struct {
    Ponto inferior_esquerdo;
    Ponto superior_direito;
} Retangulo;

int main() {
    Retangulo ret;
    
    printf("Digite as coordenadas do ponto inferior esquerdo (x y): ");
    scanf("%f %f", &ret.inferior_esquerdo.x, &ret.inferior_esquerdo.y);
    
    printf("Digite as coordenadas do ponto superior direito (x y): ");
    scanf("%f %f", &ret.superior_direito.x, &ret.superior_direito.y);
    
    float largura = ret.superior_direito.x - ret.inferior_esquerdo.x;
    float altura = ret.superior_direito.y - ret.inferior_esquerdo.y;
    float area = largura * altura;
    
    printf("Área do retângulo: %.2f", area);
    
    return 0;
}