#include <stdio.h>
#include <string.h>

int main() {
    char str[100];
    int contador[256] = {0}; // ASCII
    
    scanf("%s", str);
    
    for (int i = 0; str[i] != '\0'; i++) {
        contador[(int)str[i]]++;
    }
    
    printf("Letras repetidas: ");
    for (int i = 0; i < 256; i++) {
        if (contador[i] > 1) {
            printf("%c ", (char)i);
        }
    }
    
    return 0;
}