#include <stdio.h>

int main() {
    int M[5][5], SL[5] = {0}, SC[5] = {0};
    
    // Leitura da matriz
    for (int i = 0; i < 5; i++) {
        for (int j = 0; j < 5; j++) {
            scanf("%d", &M[i][j]);
            SL[i] += M[i][j];
            SC[j] += M[i][j];
        }
    }
    
    // Exibição da matriz
    printf("Matriz:\n");
    for (int i = 0; i < 5; i++) {
        for (int j = 0; j < 5; j++) {
            printf("%d\t", M[i][j]);
        }
        printf("\n");
    }
    
    // Exibição das somas das linhas
    printf("\nSomas das linhas:\n");
    for (int i = 0; i < 5; i++) {
        printf("Linha %d: %d\n", i, SL[i]);
    }
    
    // Exibição das somas das colunas
    printf("\nSomas das colunas:\n");
    for (int j = 0; j < 5; j++) {
        printf("Coluna %d: %d\n", j, SC[j]);
    }
    
    return 0;
}