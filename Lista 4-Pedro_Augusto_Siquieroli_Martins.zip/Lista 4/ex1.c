#include <stdio.h>
#include <stdlib.h>

int main() {
    // a) Aloca dinamicamente um array de 5 inteiros
    int *array = (int*) malloc(5 * sizeof(int));
    
    // b) Solicita os números ao usuário
    printf("Digite 5 numeros inteiros:\n");
    for(int i = 0; i < 5; i++) {
        scanf("%d", &array[i]);
    }
    
    // c) Exibe os números
    printf("Numeros digitados:\n");
    for(int i = 0; i < 5; i++) {
        printf("%d ", array[i]);
    }
    
    // d) Libera a memória
    free(array);
    return 0;
}