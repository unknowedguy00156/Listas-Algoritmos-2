#include <stdio.h>
#include <stdlib.h>

int main() {
    const int TAM = 1500;
    int *vetor = (int*) calloc(TAM, sizeof(int)); // Aloca e zera
    
    // a) Verifica zeros
    int zeros = 0;
    for(int i = 0; i < TAM; i++) {
        if(vetor[i] == 0) zeros++;
    }
    printf("Zeros: %d\n", zeros);
    
    // b) Atribui índices
    for(int i = 0; i < TAM; i++) {
        vetor[i] = i;
    }
    
    // c) Exibe extremos
    printf("Primeiros 10: ");
    for(int i = 0; i < 10; i++) printf("%d ", vetor[i]);
    
    printf("\nUltimos 10: ");
    for(int i = TAM-10; i < TAM; i++) printf("%d ", vetor[i]);
    
    free(vetor);
    return 0;
}