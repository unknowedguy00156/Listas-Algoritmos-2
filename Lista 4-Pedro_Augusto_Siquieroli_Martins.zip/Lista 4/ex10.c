#include <stdio.h>
#include <stdlib.h>
#include <time.h>

int main() {
    int n;
    do {
        printf("Tamanho do vetor (>=10): ");
        scanf("%d", &n);
    } while(n < 10);
    
    double *vetor = (double*) malloc(n * sizeof(double));
    srand(time(NULL)); // Inicializa gerador de números aleatórios
    
    // Atribui valores aleatórios aos 10 primeiros
    for(int i = 0; i < 10; i++) {
        vetor[i] = rand() % 101; // Valores entre 0 e 100
    }
    
    printf("Primeiros 10 valores:\n");
    for(int i = 0; i < 10; i++) {
        printf("%.2f ", vetor[i]);
    }
    
    free(vetor);
    return 0;
}