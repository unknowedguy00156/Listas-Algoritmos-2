#include <stdio.h>
#include <stdlib.h>

int main() {
    int bytes, tamanho;
    printf("Tamanho da memoria (bytes, multiplo de %ld): ", sizeof(int));
    scanf("%d", &bytes);
    
    // Verifica se é múltiplo
    if(bytes % sizeof(int) != 0) {
        printf("Tamanho invalido!\n");
        return 1;
    }
    
    tamanho = bytes / sizeof(int);
    int *memoria = (int*) calloc(tamanho, sizeof(int)); // Zera a memória
    
    int opcao, pos, valor;
    do {
        printf("\n1. Inserir\n2. Consultar\n3. Sair\nOpcao: ");
        scanf("%d", &opcao);
        
        if(opcao == 1 || opcao == 2) {
            printf("Posicao (0 a %d): ", tamanho - 1);
            scanf("%d", &pos);
            if(pos < 0 || pos >= tamanho) {
                printf("Posicao invalida!\n");
                continue;
            }
        }
        
        switch(opcao) {
            case 1: // Inserir
                printf("Valor: ");
                scanf("%d", &valor);
                memoria[pos] = valor;
                break;
            case 2: // Consultar
                printf("Valor na posicao %d: %d\n", pos, memoria[pos]);
                break;
            case 3: // Sair
                break;
            default:
                printf("Opcao invalida!\n");
        }
    } while(opcao != 3);
    
    free(memoria);
    return 0;
}