#include <stdio.h>
#include <stdlib.h>

int main() {
    int *vetor = NULL;
    int num, tamanho = 0;
    
    printf("Digite numeros (negativo para parar):\n");
    while(1) {
        scanf("%d", &num);
        if(num < 0) break;
        
        // Aumenta o vetor com realloc
        tamanho++;
        vetor = (int*) realloc(vetor, tamanho * sizeof(int));
        vetor[tamanho-1] = num;
    }
    
    printf("Vetor lido:\n");
    for(int i = 0; i < tamanho; i++) {
        printf("%d ", vetor[i]);
    }
    
    free(vetor);
    return 0;
}