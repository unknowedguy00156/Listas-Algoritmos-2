#include <stdio.h>
#include <stdlib.h>

typedef struct {
    int matricula;
    char sobrenome[50];
    int anoNascimento;
} Aluno;

int main() {
    int n;
    printf("Quantidade de alunos: ");
    scanf("%d", &n);
    
    Aluno *alunos = (Aluno*) malloc(n * sizeof(Aluno));
    
    // Lê dados dos alunos
    for(int i = 0; i < n; i++) {
        printf("\nAluno %d:\n", i+1);
        printf("Matricula: ");
        scanf("%d", &alunos[i].matricula);
        printf("Sobrenome: ");
        scanf("%s", alunos[i].sobrenome);
        printf("Ano de nascimento: ");
        scanf("%d", &alunos[i].anoNascimento);
    }
    
    // Exibe dados
    printf("\nDados dos alunos:\n");
    for(int i = 0; i < n; i++) {
        printf("Aluno %d: %d, %s, %d\n", i+1, 
               alunos[i].matricula, 
               alunos[i].sobrenome, 
               alunos[i].anoNascimento);
    }
    
    free(alunos);
    return 0;
}