#include <stdio.h>
#include <stdlib.h>

int main() {
    int n, x, count = 0;
    printf("Digite o tamanho do vetor (N): ");
    scanf("%d", &n);
    
    int *vetor = (int*) malloc(n * sizeof(int));
    
    printf("Digite %d valores:\n", n);
    for(int i = 0; i < n; i++) {
        scanf("%d", &vetor[i]);
    }
    
    printf("Digite o numero X: ");
    scanf("%d", &x);
    
    // Conta múltiplos
    printf("Multiplos de %d: ", x);
    for(int i = 0; i < n; i++) {
        if(vetor[i] % x == 0) {
            printf("%d ", vetor[i]);
            count++;
        }
    }
    printf("\nTotal: %d\n", count);
    
    free(vetor);
    return 0;
}