#include <stdio.h>
#include <stdlib.h>

int main() {
    int n;
    printf("Digite o tamanho do vetor: ");
    scanf("%d", &n);
    
    // Aloca memória para o vetor
    int *vetor = (int*) malloc(n * sizeof(int));
    
    // Lê os valores
    printf("Digite %d valores:\n", n);
    for(int i = 0; i < n; i++) {
        scanf("%d", &vetor[i]);
    }
    
    // Exibe o vetor
    printf("Vetor lido:\n");
    for(int i = 0; i < n; i++) {
        printf("%d ", vetor[i]);
    }
    
    free(vetor);
    return 0;
}