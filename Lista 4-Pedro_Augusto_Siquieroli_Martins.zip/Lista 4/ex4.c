#include <stdio.h>
#include <stdlib.h>

int main() {
    int tam;
    printf("Digite o tamanho da string: ");
    scanf("%d", &tam);
    getchar(); // Consome o '\n' deixado pelo scanf
    
    // Aloca memória (+1 para o '\0')
    char *str = (char*) malloc((tam + 1) * sizeof(char));
    
    printf("Digite a string: ");
    fgets(str, tam + 1, stdin); // Lê a string
    
    // Remove vogais
    for(int i = 0; str[i] != '\0'; i++) {
        char c = str[i];
        if(!(c == 'a' || c == 'e' || c == 'i' || c == 'o' || c == 'u' ||
             c == 'A' || c == 'E' || c == 'I' || c == 'O' || c == 'U')) {
            printf("%c", c);
        }
    }
    
    free(str);
    return 0;
}