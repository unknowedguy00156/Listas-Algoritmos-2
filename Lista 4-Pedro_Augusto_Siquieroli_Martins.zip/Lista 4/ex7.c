#include <stdio.h>
#include <stdlib.h>

int main() {
    int sorteio[6], bilhete[6], acertos = 0;
    
    printf("Numeros sorteados (6):\n");
    for(int i = 0; i < 6; i++) scanf("%d", &sorteio[i]);
    
    printf("Seu bilhete (6):\n");
    for(int i = 0; i < 6; i++) scanf("%d", &bilhete[i]);
    
    // Conta acertos
    for(int i = 0; i < 6; i++) {
        for(int j = 0; j < 6; j++) {
            if(bilhete[i] == sorteio[j]) {
                acertos++;
                break;
            }
        }
    }
    
    // Aloca vetor de acertos
    int *corretos = (int*) malloc(acertos * sizeof(int));
    int idx = 0;
    
    // Preenche com os números corretos
    for(int i = 0; i < 6; i++) {
        for(int j = 0; j < 6; j++) {
            if(bilhete[i] == sorteio[j]) {
                corretos[idx++] = bilhete[i];
                break;
            }
        }
    }
    
    printf("\nSorteados: ");
    for(int i = 0; i < 6; i++) printf("%d ", sorteio[i]);
    
    printf("\nAcertos: ");
    for(int i = 0; i < acertos; i++) printf("%d ", corretos[i]);
    
    free(corretos);
    return 0;
}