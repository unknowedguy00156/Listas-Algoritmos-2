#include <stdio.h>
#include <stdlib.h>
#include <string.h>

typedef struct {
    int codigo;
    char nome[51];
    int quantidade;
    float preco;
} Produto;

int main() {
    int n;
    printf("Quantidade de produtos: ");
    scanf("%d", &n);
    
    Produto *produtos = (Produto*) malloc(n * sizeof(Produto));
    
    // Lê produtos
    for(int i = 0; i < n; i++) {
        printf("\nProduto %d:\n", i+1);
        printf("Codigo: ");
        scanf("%d", &produtos[i].codigo);
        printf("Nome: ");
        scanf("%s", produtos[i].nome);
        printf("Quantidade: ");
        scanf("%d", &produtos[i].quantidade);
        printf("Preco: ");
        scanf("%f", &produtos[i].preco);
    }
    
    // Encontra maior preço e maior quantidade
    int idx_maior_preco = 0, idx_maior_qtde = 0;
    for(int i = 1; i < n; i++) {
        if(produtos[i].preco > produtos[idx_maior_preco].preco) 
            idx_maior_preco = i;
        if(produtos[i].quantidade > produtos[idx_maior_qtde].quantidade) 
            idx_maior_qtde = i;
    }
    
    printf("\nProduto mais caro: %s (R$ %.2f)\n", 
           produtos[idx_maior_preco].nome, 
           produtos[idx_maior_preco].preco);
           
    printf("Produto com maior estoque: %s (%d unidades)\n", 
           produtos[idx_maior_qtde].nome, 
           produtos[idx_maior_qtde].quantidade);
    
    free(produtos);
    return 0;
}
