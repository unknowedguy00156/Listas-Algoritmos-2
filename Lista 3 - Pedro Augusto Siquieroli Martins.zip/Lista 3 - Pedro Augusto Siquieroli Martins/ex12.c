#include <stdio.h>

void frac(float num, int *inteiro, float *fracao) {
    *inteiro = (int)num;
    *fracao = num - *inteiro;
}

int main() {
    float numero, parteFracionaria;
    int parteInteira;

    printf("Digite um número real: ");
    scanf("%f", &numero);

    frac(numero, &parteInteira, &parteFracionaria);

    printf("Parte inteira: %d\n", parteInteira);
    printf("Parte fracionária: %.4f\n", parteFracionaria);

    return 0;
}
