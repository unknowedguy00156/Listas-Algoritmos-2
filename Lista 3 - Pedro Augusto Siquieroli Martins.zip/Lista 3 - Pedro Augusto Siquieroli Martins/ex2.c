#include <stdio.h>

void main(){

int num1 = 12;
int num2 = 25;

int *ptr1;
int *ptr2;

ptr1 = &num1;
ptr2 = &num2;



if(&num1 > &num2) printf("Maior endereço: %p (num1)\n", (void*)&num1);
else printf("Maior endereço: %p (num1)\n", (void*)&num2);






}