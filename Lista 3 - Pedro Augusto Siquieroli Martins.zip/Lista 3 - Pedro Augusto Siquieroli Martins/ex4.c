#include <stdio.h>

void troca(int *a, int *b) {
    int temp = *a;
    *a = *b;
    *b = temp;
}

int main() {
    int A, B;
    printf("Digite A e B: ");
    scanf("%d %d", &A, &B);

    troca(&A, &B);

    printf("Após troca: A = %d, B = %d\n", A, B);
    return 0;
}
