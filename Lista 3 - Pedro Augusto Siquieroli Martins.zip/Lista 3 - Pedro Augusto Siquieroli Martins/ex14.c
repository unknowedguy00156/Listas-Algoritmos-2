#include <stdio.h>

void lerNotas(float *n1, float *n2) {
    do {
        printf("Digite a nota 1: ");
        scanf("%f", n1);
    } while (*n1 < 0 || *n1 > 10);

    do {
        printf("Digite a nota 2: ");
        scanf("%f", n2);
    } while (*n2 < 0 || *n2 > 10);
}

void calcularMedias(float n1, float n2, float *mediaSimples, float *mediaPonderada) {
    *mediaSimples = (n1 + n2) / 2.0;
    *mediaPonderada = (n1 + 2 * n2) / 3.0;
}

int main() {
    float nota1, nota2, mediaS, mediaP;

    lerNotas(&nota1, &nota2);
    calcularMedias(nota1, nota2, &mediaS, &mediaP);

    printf("Média simples: %.2f\n", mediaS);
    printf("Média ponderada (peso 2 na segunda): %.2f\n", mediaP);

    return 0;
}
