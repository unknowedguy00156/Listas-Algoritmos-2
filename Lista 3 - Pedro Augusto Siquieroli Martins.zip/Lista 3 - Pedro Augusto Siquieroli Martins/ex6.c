#include <stdio.h>

void dobra_soma(int *a, int *b, int *soma) {
    *a = *a * 2;
    *b = *b * 2;
    *soma = *a + *b;
}

int main() {
    int A, B, resultado;
    printf("Digite A e B: ");
    scanf("%d %d", &A, &B);

    dobra_soma(&A, &B, &resultado);

    printf("Dobros: A = %d, B = %d\n", A, B);
    printf("Soma dos dobros: %d\n", resultado);

    return 0;
}

