#include <stdio.h>

int main() {
    int vetor[5];

    for (int i = 0; i < 5; i++) {
        printf("Digite o valor %d: ", i + 1);
        scanf("%d", &vetor[i]);
    }

    for (int i = 0; i < 5; i++) {
        if (vetor[i] % 2 == 0) {
            printf("Valor par %d em vetor[%d] no endereço %p\n", vetor[i], i, (void*)&vetor[i]);
        }
    }

    return 0;
}
