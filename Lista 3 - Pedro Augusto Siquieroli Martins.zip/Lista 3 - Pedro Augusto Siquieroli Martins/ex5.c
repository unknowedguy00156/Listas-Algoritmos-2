#include <stdio.h>

void ordenar(int *a, int *b) {
    if (*a < *b) {
        int temp = *a;
        *a = *b;
        *b = temp;
    }
}

int main() {
    int A, B;
    printf("Digite A e B: ");
    scanf("%d %d", &A, &B);

    ordenar(&A, &B);
    printf("Maior em A = %d, Menor em B = %d\n", A, B);

    return 0;
}
