#include <stdio.h>

int main(){
int num1 = 0, num2 = 0;
printf("Digite 2 numeros inteiros: ");
scanf("%d %d",&num1,&num2);

if(&num1 > &num2) printf("Conteudo do maior endereco: %d",num1); 
else printf("Conteudo do maior endereco: %d",num2);


}