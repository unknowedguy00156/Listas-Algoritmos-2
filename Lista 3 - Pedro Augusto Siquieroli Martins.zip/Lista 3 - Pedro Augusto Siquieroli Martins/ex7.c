#include <stdio.h>

void soma_sem_retorno(int *a, int *b) {
    *a = *a + *b;
}

int main() {
    int A, B;
    printf("Digite A e B: ");
    scanf("%d %d", &A, &B);

    soma_sem_retorno(&A, &B);

    printf("A (soma): %d, B: %d\n", A, B);

    return 0;
}
