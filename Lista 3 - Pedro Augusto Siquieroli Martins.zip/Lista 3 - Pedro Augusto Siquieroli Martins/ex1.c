//1. Escreva um programa que declare um inteiro, um real e um char, e ponteiros para inteiro, real e char.
// Associe as vari�veis aos ponteiros (use &). Modifique os valores de cada vari�vel
//usando os ponteiros. Imprima os valores das vari�veis antes e ap�s a modifica��o.

#include <stdio.h>

int main(){

    int x = 12; // declara x = 12
    float y = 1.56; // declara y = 1.56
    char z = 'A'; // declara z = 'A'



    int *i; // ponteiro para inteiro
    float *f; // ponteiro para float
    char *c; //ponteiro para char

    i = &x; // i = endere�o de x
    f = &y; // y = endere�o de y
    c = &z;

    printf("Valores antes da modificacao:\n");
    printf("%d\n",x);
    printf("%.2f\n",y);
    printf("%c\n",z);

    *i = 24;
    *f = 6.28;
    *c = 'B';

     printf("Valores depois da modificacao:\n");
    printf("%d\n",x);
    printf("%.2f\n",y);
    printf("%c\n",z);



return 0;

}
