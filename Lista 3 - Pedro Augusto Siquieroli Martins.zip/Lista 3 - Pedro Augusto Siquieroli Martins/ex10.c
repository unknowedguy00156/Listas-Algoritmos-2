#include <stdio.h>

int main() {
    int vetor[5];
    int *p = vetor;

    for (int i = 0; i < 5; i++) {
        printf("Digite o valor %d: ", i + 1);
        scanf("%d", p + i);
    }

    for (int i = 0; i < 5; i++) {
        printf("Dobro do valor %d: %d\n", i + 1, 2 * (*(p + i)));
    }

    return 0;
}
